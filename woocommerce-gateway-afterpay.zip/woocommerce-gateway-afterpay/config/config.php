<?php
$environments = array();
$environments["sandbox"] 	=	array(
									"name"		=>	"Sandbox Test",
									"api_url"	=>	"https://api-sandbox.secure-afterpay.com.au/",
									"web_url"	=>	"https://www-sandbox.secure-afterpay.com.au/",
								);

$environments["production"] =	array(
									"name"		=>	"Production",
									"api_url"	=>	"https://api.secure-afterpay.com.au/",
									"web_url"	=>	"https://www.secure-afterpay.com.au/",
								);

?>